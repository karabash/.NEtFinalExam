﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EnvirmentCrime.Models;
using System.IO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EnvironementCrime.Controllers
{
    [Authorize(Roles = "Investigator")]
    public class InvestigatorController : Controller
    {
        private IKommunRepository repository;
        private IHostingEnvironment environment;

        public InvestigatorController(IKommunRepository repository, IHostingEnvironment environment)
        {
            this.repository = repository;

            this.environment = environment;
        }
        [Authorize(Roles = "Investigator")]
        public ViewResult StartInvestigator(int id)
        {

            return View(this.repository);
        }


        // GET: /<controller>/
        public ViewResult CrimeInvestigator( int id)
        {

            TempData["ID"] = id;
            ViewBag.ID = id;

            ViewBag.ListOfErrandStatus = this.repository.ErrandStatusess.OrderBy(eStatus => eStatus.StatusId);
            return View(new ErrandStatus());

        }




     [HttpPost]
        public RedirectToActionResult UpLoadAllFiles(string StatusId,  string events, string information, IFormFile loadImage, IFormFile loadSample) {
            int errandId = int.Parse(TempData["ID"].ToString());
      

            if (loadSample != null)
            {
                UploadFiles(loadSample, errandId);
            }
            
            if (loadImage != null)
            {
                UploadPictures(loadImage, errandId);
            } 

            repository.UpdateInvest(StatusId, errandId, events, information);

            return RedirectToAction("CrimeInvestigator", new { id = errandId });
        }




        [HttpPost]
        public void UploadFiles(IFormFile loadSample, int errandId)
        {
            var tempPath = Path.GetTempFileName();
            if (loadSample.Length > 0)
            {
                using (var stream = new FileStream(tempPath, FileMode.Create))
                {
                    loadSample.CopyToAsync(stream);
                }
            }

            var path = Path.Combine(environment.WebRootPath, "samples", loadSample.FileName);

            System.IO.File.Move(tempPath, path);
            //sample.SampleName = loadSample.ToString();
            repository.CreateSample(errandId, loadSample.FileName);

        }
        
        [HttpPost]
        public void UploadPictures(IFormFile loadImage, int errandId)
        {
            var tempPath = Path.GetTempFileName();
            if (loadImage.Length > 0)
            {
                using (var stream = new FileStream(tempPath, FileMode.Create))
                {
                    loadImage.CopyToAsync(stream);
                }
            }

            var path = Path.Combine(environment.WebRootPath, "pictures", loadImage.FileName);

            System.IO.File.Move(tempPath, path);
            repository.CreatePicture(errandId, loadImage.FileName);

        }
        


    }
}
