﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;

using System.IO;
using EnvirmentCrime.Models;
using Microsoft.AspNetCore.Authorization;
// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EnvironementCrime.Controllers
{
    //ANVÄND FÖR RAPPORT
    [Authorize(Roles = "Manager")]
    public class ManagerController : Controller
    {
        // GET: /<controller>/
        private IKommunRepository repository;



        public ManagerController(IKommunRepository repository)
        {
            this.repository = repository;
        }
        /// <summary>
        /// Anropar CrimeManager viewn 
        /// </summary>
        /// <param name="id">string type id Initierar ViewBag.ID  </param>
        /// <returns></returns>
        public ViewResult CrimeManager(int id)
        {
            TempData["ID"] = id;
            ViewBag.ID = id;
           
            ViewBag.ListOfEmp = this.repository.Employees.OrderBy(emp => emp.EmployeeName);
            return View();

        }
        [Authorize(Roles = "Manager")]
        public ViewResult StartManager()
        {
            return View(this.repository);

        }
       
        [HttpPost]
        public IActionResult CrimeCManagerPost(string EmployeeId, bool noAction, string reason)
        {
            int errandId = int.Parse(TempData["ID"].ToString());
            Errand errand = repository.Errands.FirstOrDefault(e => e.ErrandId == errandId);
            repository.UpdateCrimeM(errandId, EmployeeId, noAction, reason);
            return RedirectToAction("CrimeManager", new { id = errand.ErrandId });
        }   

      
//den temporära sökvägen

        public ActionResult CheckBoxTest()
        {

            return View();
        }

        
    }
}
