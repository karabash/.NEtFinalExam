﻿using Microsoft.AspNetCore.Mvc;
using EnvirmentCrime.Models;
using EnvirmentCrime.Infrastructure;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;

namespace EnvirmentCrime.Controllers
{
    public class HomeController : Controller
    {
        private  IKommunRepository envVar;

        public HomeController(IKommunRepository iKommunRepository) {
            envVar = iKommunRepository;
        }

        public ViewResult Index()
        {
            ViewBag.Title = "Hem";
            var myErrand = HttpContext.Session.GetJson<Errand>("NewErrand");
            if (myErrand == null)
            {
                return View();
            }
            else {
                return View(myErrand);

            }
        }
        [HttpPost]
        public ViewResult Validate(Errand errand, Sequence sequence)
        {
            HttpContext.Session.SetJson("NewErrand", errand);
            return View("Validate", errand);

        }

        public ViewResult Thanks(Errand errand, Sequence sequence)
        {
            this.envVar.SaveSequence(sequence);
            sequence.CurrentValue = 200 + sequence.Id;
            errand.RefNumber = "2018-45-" + sequence.CurrentValue;


            envVar.SaveErrand(errand);


            //Spara errand uppgifter i databasen
            HttpContext.Session.Remove("NewErrand");
            ViewBag.Title = "Thanks";
            ViewBag.RefNumber = $"{errand.RefNumber}";
            return View();
        }
        public ViewResult FAQ()
        {
            ViewBag.Title = "FAQ";

            return View();
        }
        public ViewResult Contact()
        {
            ViewBag.Title = "Validate";

            return View();
        }
        public ViewResult Services()
        {
            ViewBag.Title = "Tjänster";

            return View();
        }

        [AllowAnonymous]
        public ViewResult Login(string returnUrl)
        {
            return View(new LoginModel
            {
                ReturnUrl = returnUrl
            });
        }
    }
}
