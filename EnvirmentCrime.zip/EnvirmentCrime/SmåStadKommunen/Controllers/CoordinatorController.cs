﻿using EnvirmentCrime.Infrastructure;
using EnvirmentCrime.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EnvironementCrime.Controllers
{
    [Authorize(Roles = "Coordinator")]
    public class CoordinatorController : Controller
    {
        private IKommunRepository repository;

        public CoordinatorController(IKommunRepository repository)
        {
            this.repository = repository;
        }

       [Authorize(Roles = "Coordinator")]
        public ViewResult CrimeCoordinator(int id)
        {
            
            TempData["ID"] = id;
            ViewBag.ID = id;

            ViewBag.ListOfDepartments = from dep in this.repository.Departments where !(dep.DepartmentName.Equals("Småstads kommun")) select dep;
            return View();
        }

        [HttpPost]
        public RedirectToActionResult CrimeCoordinatorPost(string DepartmentId)
        {

            int errandId = int.Parse(TempData["ID"].ToString());
            Errand errand = repository.Errands.FirstOrDefault(e => e.ErrandId == errandId);
            repository.UpdateDepartmentId(errandId, DepartmentId);
            return RedirectToAction("CrimeCoordinator", new { id = errand.ErrandId });

        }
        [Authorize(Roles = "Coordinator")]
        public ViewResult StartCoordinator()
        {

            return View(this.repository);


        }
        public ViewResult ReportCrime()
        {
            var myErrand = HttpContext.Session.GetJson<Errand>("NewErrand");
            if (myErrand == null)
            {
                return View();
            }
            else
            {
                return View(myErrand);

            }
        }

        public ViewResult Thanks(Errand errand, Sequence sequence)
        {
            this.repository.SaveSequence(sequence);
            sequence.CurrentValue = 200 + sequence.Id;
            errand.RefNumber = "2018-45-" + sequence.CurrentValue;


            this.repository.SaveErrand(errand);


            //Spara errand uppgifter i databasen
            HttpContext.Session.Remove("NewErrand");
            ViewBag.Title = "Thanks";
            ViewBag.RefNumber = $"{errand.RefNumber}";
            return View();
        }

        [HttpPost]
        public ViewResult Validate(Errand errand)
        {
            HttpContext.Session.SetJson("NewErrand", errand);

            return View("Validate", errand);

        }
        //kiss är just nu methoden gör den
        public RedirectToActionResult UpdateErrand(string errandId, string departmentId)
        {
            int id = int.Parse(errandId);

            Errand errand = repository.Errands.FirstOrDefault(e => e.ErrandId == id);
            if (errand != null)
            {
                errand.DepartmentId = departmentId;
                repository.SaveErrand(errand);

            }
            return RedirectToAction("CrimeCoordinatorPost", "Coordinator", 1);
        }
    }
}


