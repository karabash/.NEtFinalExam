﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnvirmentCrime.Models
{
    public class Department
    {
      public  String DepartmentId { get; set; }
      public String DepartmentName { get; set; }
    }
}
