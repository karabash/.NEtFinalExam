﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace EnvirmentCrime.Models
{
    public class ErrandStatus
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public  String StatusId { get; set; }
      public String StatusName { get; set; }
    }
}
