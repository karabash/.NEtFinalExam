﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EnvirmentCrime.Models
{
    public class LoginModel
    {
        //[Display(Name ="Fullständigt namn")]
        [Required(ErrorMessage ="Du måste fylla i ditt namn")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Vänligen fyll i lösenord")]
        [Display(Name = "Lösenord")]
        [UIHint("Password")]
        public string Password { get; set; }

        public string ReturnUrl {
            get;            set;
             
        }
    }
}
