﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EnvirmentCrime.Models
{
    public class Errand
    {
        private string informerName;

        public int ErrandId { get; set; }

        public string RefNumber { get; set; }

        [Display(Name = "Place")]
        [Required(ErrorMessage = "Du måste fylla i - Var har brottet skett någonstans?")]
        public string Place { get; set; }

        [Display(Name = "TypeOfCrime")]
        [Required(ErrorMessage = "Du måste fylla i Vilken typ av brott?")]
        public string TypeOfCrime { get; set; }

        [Display(Name = "DateOfObservation")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        [Required(ErrorMessage = "Du måste fylla i Date")]
        public DateTime DateOfObservation { get; set; }

        public string Observation { get; set; }
        public string InvestigatorInfo { get; set; }
        public string InvestigatorAction { get; set; }

        [Required(ErrorMessage = "Du måste fylla i ditt namn")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]

        public string InformerName { get => informerName; set => informerName = value; }

        [RegularExpression("^[0-9]*$", ErrorMessage = "Du måste fylla i - Din telefon")]
        [Required(ErrorMessage = "Du måste fylla i phoneNummer")]
        public string InformerPhone { get; set; }

        public string StatusId { get; set; }

        public string DepartmentId { get; set; }

        public string EmployeeId { get; set; }

        public ICollection<Sample> Samples { get; set; }

        public ICollection<Picture> Pictures { get; set; }

    }
}
