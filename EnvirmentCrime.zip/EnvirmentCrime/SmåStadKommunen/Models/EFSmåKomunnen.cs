﻿using EnvirmentCrime.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EnvirmentCrime.Models
{

    public class EFSmåKomunnen : IKommunRepository
    {
        private IHttpContextAccessor contextAcc;

        private ApplicationDbContext context;
        public EFSmåKomunnen(ApplicationDbContext ctx, IHttpContextAccessor cont)
        {
            this.context = ctx;

            contextAcc = cont;

        }

        public IQueryable<Employee> Employees => context.Employees;
        public IQueryable<Department> Departments => context.Departments;
        public IQueryable<Errand> Errands => context.Errands.Include(e => e.Samples).Include(e => e.Pictures);
        public IQueryable<ErrandStatus> ErrandStatusess => context.ErrandStatuses;
        public IQueryable<Sequence> Sequences => context.Sequences;
        public IQueryable<Picture> Pictures => context.Pictures;
        public IQueryable<Sample> Samples => context.Samples;

        
        public IQueryable<MyErrand> showOnCoordinator()
        {
        
            var errandList = from err in Errands
                             join stat in ErrandStatusess on err.StatusId equals stat.StatusId
                             join dep in Departments on err.DepartmentId equals dep.DepartmentId
                             into departmentErrand
                             from deptE in departmentErrand.DefaultIfEmpty()
                             join em in Employees on err.EmployeeId equals em.EmployeeId
              into employeeErrand
                             from empE in employeeErrand.DefaultIfEmpty()
                             orderby err.RefNumber descending
                             select new MyErrand
{
DateOfObservation = err.DateOfObservation,
ErrandId = err.ErrandId,
RefNumber = err.RefNumber,
TypeOfCrime = err.TypeOfCrime,
StatusName = stat.StatusName,
DepertmentName = (
err.DepartmentId == null ? "ej tillsatt" : deptE.DepartmentName),
EmployeeName = (err.EmployeeId == null ? "ej tillsatt" : empE.EmployeeName),
EmployeeId = (err.EmployeeId == null ? "ej tillsatt" : empE.EmployeeId)
                             };
            return errandList;

        }

        public IQueryable<MyErrand> showOnInvestigator()
        {
            var UserName = contextAcc.HttpContext.User.Identity.Name;
            var empErrand = from err in Errands
                            join em in Employees on err.EmployeeId equals em.EmployeeId
                            where (em.EmployeeId == UserName)
                            join dep in Departments on err.DepartmentId equals dep.DepartmentId
                            join stat in ErrandStatusess on err.StatusId equals stat.StatusId
                            select
new MyErrand
{
    DateOfObservation = err.DateOfObservation,
    ErrandId = err.ErrandId,
    RefNumber = err.RefNumber,
    TypeOfCrime = err.TypeOfCrime,
    StatusName = stat.StatusName,
    DepertmentName = (
err.DepartmentId == null ? "ej tillsatt" : dep.DepartmentName),
    EmployeeName = (err.EmployeeId == null ? "ej tillsatt" : em.EmployeeName),
};
           
            return empErrand;

        }


      public  IQueryable<MyErrand> showOnManager() {

            var UserName = contextAcc.HttpContext.User.Identity.Name;
            var user = context.Employees.Where(u => u.EmployeeId == UserName).FirstOrDefault();
            var empErrand = from err in Errands
                            where(err.DepartmentId == user.DepartmentId)
                            join em in Employees on err.EmployeeId equals em.EmployeeId
                            join dep in Departments on err.DepartmentId equals dep.DepartmentId
                            join stat in ErrandStatusess on err.StatusId equals stat.StatusId
                            select new MyErrand
                            {
                                DateOfObservation = err.DateOfObservation,
                                ErrandId = err.ErrandId,
                                RefNumber = err.RefNumber,
                                TypeOfCrime = err.TypeOfCrime,
                                StatusName = stat.StatusName,
                                DepertmentName = (
 err.DepartmentId == null ? "ej tillsatt" : dep.DepartmentName),
                                EmployeeName = (err.EmployeeId == null ? "ej tillsatt" : em.EmployeeName),
                            };


            return empErrand;

        }


        public Task<Errand> GetErrandDetail(int id)
        {
            return Task.Run(() =>
            {
                var errandDetail = Errands.Where(td => td.ErrandId.Equals(id)).FirstOrDefault();
                return errandDetail;
            });
        }

        public void SaveErrand(Errand errand)
        {

            if (errand.ErrandId == 0)
            {

                errand.StatusId = "S_A";

                context.Errands.Add(errand);

            }
            else
            {
                Errand dbEntry = context.Errands.FirstOrDefault(e => e.ErrandId == errand.ErrandId);
                if (dbEntry != null)
                {


                    dbEntry.Place = errand.Place;
                    dbEntry.TypeOfCrime = errand.TypeOfCrime;
                    dbEntry.DateOfObservation = errand.DateOfObservation;
                    dbEntry.Observation = errand.Observation;
                    dbEntry.InvestigatorInfo = errand.InvestigatorInfo;
                    dbEntry.InvestigatorAction = errand.InvestigatorAction;
                    dbEntry.InformerName = errand.InformerName;
                    dbEntry.InformerPhone = errand.InformerPhone;

                    dbEntry.StatusId = errand.StatusId;
                    dbEntry.DepartmentId = errand.DepartmentId;
                    dbEntry.EmployeeId = errand.EmployeeId;

                }

            }
            context.SaveChanges();


        }

        public int SaveSequence(Sequence sequence)
        {

            if (sequence.Id == 0)
            {
                context.Sequences.Add(sequence);
            }
            else
            {
                Sequence dbEntry = context.Sequences.FirstOrDefault(s => s.Id == sequence.Id);
                if (dbEntry != null)
                {
                    dbEntry.CurrentValue = sequence.CurrentValue;
                }
            }
            context.SaveChanges();
            int id = sequence.Id;
            return id;
        }

        public void UpdateDepartmentId(int errandId, string newValue)
        {
            Errand dbEntry = this.context.Errands.FirstOrDefault(e => e.ErrandId == errandId);

            if (dbEntry != null)
            {
                dbEntry.DepartmentId = newValue;
            }
            this.context.SaveChanges();
        }


        public void UpdateCrimeM(int ErrandId, string EmployeeId, bool noAction, string reason)
        {

            Errand dbEntry = this.context.Errands.FirstOrDefault(e => e.ErrandId == ErrandId);


            if (dbEntry != null)
            {
                if (noAction)
                {

                    dbEntry.StatusId = "S_B";
                    dbEntry.InvestigatorInfo = reason;


                }
                else
                {
                    dbEntry.EmployeeId = EmployeeId;

                }
                this.context.SaveChanges();

            }
        }




        public void UpdateInvest(string StatusId, int ErrandId, string events, string information)
        {

            Errand dbEntry = this.context.Errands.FirstOrDefault(e => e.ErrandId == ErrandId);
            if (dbEntry != null)
            {
                dbEntry.StatusId = StatusId;
                dbEntry.InvestigatorAction += events + ";";
                dbEntry.InvestigatorInfo += information + ";";

            }
            this.context.SaveChanges();

        }


        public void CreateSample(int errandId, string loadSample)
        {
            Sample sample = new Sample();
            sample.SampleName = loadSample;
            sample.ErrandID = errandId;

            if (sample.SampleID == 0)
            {
                context.Samples.Add(sample);

            }

            context.SaveChanges();

        }
        public void CreatePicture(int errandId, string loadImage)
        {

            Picture picture = new Picture();
            picture.PictureName = loadImage;
            picture.ErrandId = errandId;
            if (picture.PictureId == 0)
            {
                context.Pictures.Add(picture);
            }

            context.SaveChanges();

        }

    }

}



