﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace EnvirmentCrime.Models
{/// <summary>
/// Det är en interface - contract med FakeKomun Repository
/// Istället föratt kominicera direkt med data användes IKommunRepository interface. hindrar injection
/// </summary>
    public interface IKommunRepository
    {
        IQueryable<Employee> Employees { get; }
        IQueryable<Department> Departments { get; }
        IQueryable<Errand> Errands { get; }
        IQueryable<ErrandStatus> ErrandStatusess { get; }
        IQueryable<Sequence> Sequences { get; }

        Task<Errand> GetErrandDetail(int id);

        //save
        void SaveErrand(Errand errand);

        int SaveSequence(Sequence sequence);
        void UpdateDepartmentId(int errandId, string DepartmentId);

        void UpdateCrimeM(int ErrandId, string EmployeeId, bool noAction, string reason);

        void UpdateInvest(string StatusId, int errandId, string events, string information);

        void CreateSample(int errandId, string loadSample);
        void CreatePicture(int errandId, string loadImage);
        IQueryable<MyErrand> showOnCoordinator();
        IQueryable<MyErrand> showOnInvestigator();
        IQueryable<MyErrand>  showOnManager();


    }



}



