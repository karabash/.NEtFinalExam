﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EnvirmentCrime.Models;
namespace EnvirmentCrime.Components
{
    public class Form : ViewComponent
    {
        private IKommunRepository repository;

       
        public Form(IKommunRepository repo ) {
            this.repository = repo;
        }
        
        public IViewComponentResult Invoke() {
            return  View("Form");
        }
    }
}
