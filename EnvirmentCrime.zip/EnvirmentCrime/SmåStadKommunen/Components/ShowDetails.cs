﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EnvirmentCrime.Models;
namespace EnvirmentCrime.Components
{
    /// <summary>
    /// ShowDetails class är component som tar hand om invoke methoder. Ärver av ViewComponents för att öka sina constans och functions.
    ///  Microsoft.AspNetCore.Mvc
    /// </summary>
    public class ShowDetails : ViewComponent
    {
        //Det är en instance variable av IKommunRepository interface
        private IKommunRepository repository;

        /// <summary>
        /// Initierar instance class object 
        /// </summary>
        /// <param name="repo">Det är en new IKommunRepository</param>
        /// <returns> IKommunRepository interface
        public ShowDetails(IKommunRepository repo ) {
            this.repository = repo;
        }
        /// <summary>
        /// Komunicerar med GetErrandDetail för att hitta klickat item id.
        /// </summary>
        /// <param name="id">Det är type av string to pass GetErrandDetail abstract method </param>
        /// <returns>Retunerar en asynchronous result view till Default - ViewComponent av object Errand </returns>
        //Be Aware of method signature - ifall det behöbs refactory InvokeSync anropats action - InvokeSync anropar default view
        public async Task<IViewComponentResult> InvokeAsync(int id) {
            //GetErrandDetail(id) anropar repository(FakeKommunRepository) för att hämta ErrandDetail och skickar id av type string
            var objOfDetail = await this.repository.GetErrandDetail(id);
            return View(objOfDetail);
        }
    }
}
